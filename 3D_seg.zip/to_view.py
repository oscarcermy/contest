import trimesh

mesh = trimesh.load("car_semantic.glb")
mesh.show()
